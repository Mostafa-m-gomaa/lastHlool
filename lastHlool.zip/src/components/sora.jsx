import React from 'react'

const Sora = () => {
  return (
    <div className="fixed w-full h-full top-0 left-0 bg-black/50 z-50 flex items-center justify-center">
      <img src="https://cdn.dribbble.com/users/1162077/screenshots/3848910/media/2f1b3c8d4a5e6f9b0c3d8e2f4c1a5b6d.gif" alt="Loading..." className='max-w-[90%] max-h-[90%] object-contain' />
wdwd        
    </div>
  )
}

export default Sora